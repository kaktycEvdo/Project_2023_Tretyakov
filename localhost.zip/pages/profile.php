<?php
    echo '
    <div class="profile_container">
        <div class="profile_brief">
            <div class="profile_name_img">
                <img src="static/e93161a711d78c374f9a863188be1edc.jpg">
                <div>фамилия имя </div>
            </div>
            <div class="profile_brief_buttons">
                <button>Исполнитель</button>
                <button>Заказчик</button>
            </div>
        </div>
        <div>
            <div class="profile_about">
                <div>О себе:</div>
                <textarea disabled="">admin</textarea>
            </div>
            <div class="profile_charas">
                <div>Характеристики:</div>
                <div>
                    <div>💖Хулиганом</div>
                    <div>Атакованный</div>
                    <div>Компьютер</div>
                    <div>Еле</div>
                    <div>Работает✨</div>
                </div>
            </div>
        </div>
    </div>
    '
?>