<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>КФ</title>
    <link rel="stylesheet" href="static/styles.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans">
</head>
<body>
    <div id="main">
        <script src="static/scripts.js"></script>
        <div class="main_content">
            <div class="iblock1">
                мы крутые! мы крутые! мы крутые!
            </div>
            <div class="iblock2">
                <div>
                    <img src="static/images.jpg"/>
                    <div>имя</div>
                    <div>текст</div>
                </div>
                <div>
                    <img src="static/images.jpg"/>
                    <div>имя</div>
                    <div>текст</div>
                </div>
                <div>
                    <img src="static/images.jpg"/>
                    <div>имя</div>
                    <div>текст</div>
                </div>
            </div>
            <div class="iblock3">
                в общем заказывайте че надо окда
            </div>
        </div>
    </div>
</body>
</html>