<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>КФ</title>
    <link rel="stylesheet" href="static/styles.css">
    <script type="module" src="static/models.js"></script>
    <script type="module" src="components/header.js"></script>
    <script src="static/scripts.js"></script>
</head>
<body>
    <header></header>
    <main id="content">
        
    </main>
    <div id="loading">???</div>
    <script>linkcontent("pages/index.php")</script>
</body>
</html>